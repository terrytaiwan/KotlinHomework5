package com.example.lab16_2

import android.content.ContentValues
import android.net.Uri
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    private val items: ArrayList<String> = ArrayList()
    private lateinit var adapter: ArrayAdapter<String>

    // 定義 Provider 的 Uri
    private val uri = Uri.parse("content://com.example.lab16")

    // 定義 UI 元件變數，避免重複查找
    private lateinit var edBook: EditText
    private lateinit var edPrice: EditText
    private lateinit var btnInsert: Button
    private lateinit var btnUpdate: Button
    private lateinit var btnDelete: Button
    private lateinit var btnQuery: Button
    private lateinit var listView: ListView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // 初始化 UI 元件
        initViews()

        // 宣告 Adapter 並連結 ListView
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, items)
        listView.adapter = adapter

        // 設定監聽器
        setListener()
    }

    private fun initViews() {
        edBook = findViewById(R.id.edBook)
        edPrice = findViewById(R.id.edPrice)
        btnInsert = findViewById(R.id.btnInsert)
        btnUpdate = findViewById(R.id.btnUpdate)
        btnDelete = findViewById(R.id.btnDelete)
        btnQuery = findViewById(R.id.btnQuery)
        listView = findViewById(R.id.listView)
    }

    private fun setListener() {
        btnInsert.setOnClickListener {
            val name = edBook.text.toString()
            val price = edPrice.text.toString()

            if (name.isEmpty() || price.isEmpty()) {
                showToast("欄位請勿留空")
            } else {
                val values = ContentValues().apply {
                    put("book", name)
                    put("price", price)
                }
                // 透過 Resolver 向 Provider 新增一筆書籍紀錄
                val contentUri = contentResolver.insert(uri, values)

                if (contentUri != null) {
                    showToast("新增:$name, 價格:$price")
                    cleanEditText()
                } else {
                    showToast("新增失敗")
                }
            }
        }

        btnUpdate.setOnClickListener {
            val name = edBook.text.toString()
            val price = edPrice.text.toString()

            if (name.isEmpty() || price.isEmpty()) {
                showToast("欄位請勿留空")
            } else {
                val values = ContentValues().apply {
                    put("price", price)
                }
                // 注意：這裡配合 Lab16_1 Provider 的特殊設計，selection 參數直接傳入「書名」
                val count = contentResolver.update(uri, values, name, null)

                if (count > 0) {
                    showToast("更新:$name, 價格:$price")
                    cleanEditText()
                } else {
                    showToast("更新失敗")
                }
            }
        }

        btnDelete.setOnClickListener {
            val name = edBook.text.toString()

            if (name.isEmpty()) {
                showToast("書名請勿留空")
            } else {
                // 同樣配合 Provider 設計，selection 直接傳入「書名」
                val count = contentResolver.delete(uri, name, null)

                if (count > 0) {
                    showToast("刪除:$name")
                    cleanEditText()
                } else {
                    showToast("刪除失敗")
                }
            }
        }

        btnQuery.setOnClickListener {
            val name = edBook.text.toString()
            // 若無輸入書名則條件為 null，反之條件為特定書名
            val selection = name.ifEmpty { null }

            items.clear()

            // 優化重點：使用 use 自動關閉 Cursor，避免記憶體洩漏
            contentResolver.query(uri, null, selection, null, null)?.use { cursor ->
                showToast("共有${cursor.count}筆資料")

                // 使用標準 while 迴圈遍歷 Cursor
                while (cursor.moveToNext()) {
                    items.add("書名:${cursor.getString(0)}\t\t\t\t價格:${cursor.getInt(1)}")
                }
            }

            adapter.notifyDataSetChanged()
        }
    }

    private fun showToast(text: String) =
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show()

    private fun cleanEditText() {
        edBook.setText("")
        edPrice.setText("")
    }
}


/*效能優化：將 findViewById 移至 onCreate 初始化，避免在每次點擊按鈕時重複查找 View。

程式碼簡潔度：使用 Kotlin 的 apply 區塊來設定 ContentValues，讓程式碼更整潔。

Cursor 安全性：使用 Kotlin 的 ?.use { } 語法來處理 Cursor，確保查詢結束後會自動關閉，避免記憶體洩漏。

迴圈優化：使用標準的 while (cursor.moveToNext()) 來遍歷資料，比原本的 for 迴圈更直觀且符合標準寫法。
*/