package com.example.lab15

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class MyDBHelper(
    context: Context,
    name: String = DB_NAME,
    factory: SQLiteDatabase.CursorFactory? = null,
    version: Int = VERSION
) : SQLiteOpenHelper(context, name, factory, version) {

    companion object {
        // 資料庫設定 (通常維持 private 即可)
      private const val DB_NAME = "mdatabase.db" // 講義中的資料庫名稱 [cite: 544]
       private const val VERSION = 1              // 資料庫版本 [cite: 545]

        // 公開常數：讓 MainActivity 也能存取這些名稱，避免打錯字
        const val TABLE_NAME = "myTable"  // 資料表名稱 [cite: 552]
        const val COL_BOOK = "book"       // 欄位: 書名
        const val COL_PRICE = "price"     // 欄位: 價格
    }

    override fun onCreate(db: SQLiteDatabase) {
        // 使用常數與字串樣板 (String Template) 組合成 SQL
        // 這樣可以清楚看到結構：CREATE TABLE myTable (book text PRIMARY KEY, price integer NOT NULL)
        val sql = "CREATE TABLE $TABLE_NAME ($COL_BOOK text PRIMARY KEY, $COL_PRICE integer NOT NULL)"
        db.execSQL(sql) // [cite: 552]
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // 升級時刪除舊資料表 [cite: 559]
        db.execSQL("DROP TABLE IF EXISTS $TABLE_NAME")
        onCreate(db)
    }
}

//常數提取 (Companion Object)：

//將 myTable、book、price 提取為 const val。

//好處：當你在 MainActivity 寫查詢語法時（例如 UPDATE ... WHERE book = ?），可以直接使用 MyDBHelper.COL_BOOK，而不用手打 "book"，減少打錯字的風險。

//SQL 語法使用字串樣板：

//使用 $ 符號將變數直接帶入 SQL 字串中，程式碼可讀性更高，也更容易維護。

//預設參數：

//保留了你原本使用的 Kotlin 預設參數功能 (name: String = DB_NAME)，這很棒，讓呼叫時可以很簡潔：MyDBHelper(this) 即可。