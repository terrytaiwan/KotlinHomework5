package com.example.lab15

import android.database.sqlite.SQLiteDatabase
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.lang.Exception

class MainActivity : AppCompatActivity() {
    private var items: ArrayList<String> = ArrayList()
    private lateinit var adapter: ArrayAdapter<String>
    private lateinit var dbrw: SQLiteDatabase

    // 先宣告變數，稍後在 onCreate 初始化，避免重複 findViewById
    private lateinit var edBook: EditText
    private lateinit var edPrice: EditText
    private lateinit var btnInsert: Button
    private lateinit var btnUpdate: Button
    private lateinit var btnDelete: Button
    private lateinit var btnQuery: Button
    private lateinit var listView: ListView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        // 設定視窗邊界 (EdgeToEdge)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // 1. 初始化 UI 元件
        edBook = findViewById(R.id.edBook)
        edPrice = findViewById(R.id.edPrice)
        btnInsert = findViewById(R.id.btnInsert)
        btnUpdate = findViewById(R.id.btnUpdate)
        btnDelete = findViewById(R.id.btnDelete)
        btnQuery = findViewById(R.id.btnQuery)
        listView = findViewById(R.id.listView)

        // 2. 取得資料庫實體 (需搭配 MyDBHelper 類別)
        dbrw = MyDBHelper(this).writableDatabase

        // 3. 宣告 Adapter 並連結 ListView
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, items)
        listView.adapter = adapter

        // 4. 設定按鈕監聽器
        setListener()
    }

    override fun onDestroy() {
        super.onDestroy()
        dbrw.close() // 應用程式關閉時，記得關閉資料庫連線
    }

    private fun setListener() {
        // --- 新增功能 ---
        btnInsert.setOnClickListener {
            if (edBook.text.isEmpty() || edPrice.text.isEmpty()) {
                showToast("欄位請勿留空")
            } else {
                try {
                    // 使用 arrayOf 傳入參數，防止 SQL Injection
                    dbrw.execSQL(
                        "INSERT INTO myTable(book, price) VALUES(?,?)",
                        arrayOf(edBook.text.toString(), edPrice.text.toString())
                    )
                    showToast("新增:${edBook.text}, 價格:${edPrice.text}")
                    cleanEditText()
                } catch (e: Exception) {
                    showToast("新增失敗:$e")
                }
            }
        }

        // --- 修改功能 ---
        btnUpdate.setOnClickListener {
            if (edBook.text.isEmpty() || edPrice.text.isEmpty()) {
                showToast("欄位請勿留空")
            } else {
                try {
                    // 使用 WHERE book = ? 來鎖定書籍，比用 LIKE 更精確
                    dbrw.execSQL(
                        "UPDATE myTable SET price = ? WHERE book = ?",
                        arrayOf(edPrice.text.toString(), edBook.text.toString())
                    )
                    showToast("更新:${edBook.text}, 價格:${edPrice.text}")
                    cleanEditText()
                } catch (e: Exception) {
                    showToast("更新失敗:$e")
                }
            }
        }

        // --- 刪除功能 ---
        btnDelete.setOnClickListener {
            if (edBook.text.isEmpty()) {
                showToast("書名請勿留空")
            } else {
                try {
                    dbrw.execSQL(
                        "DELETE FROM myTable WHERE book = ?",
                        arrayOf(edBook.text.toString())
                    )
                    showToast("刪除:${edBook.text}")
                    cleanEditText()
                } catch (e: Exception) {
                    showToast("刪除失敗:$e")
                }
            }
        }

        // --- 查詢功能 ---
        btnQuery.setOnClickListener {
            val queryString = if (edBook.text.isEmpty()) {
                "SELECT * FROM myTable"
            } else {
                "SELECT * FROM myTable WHERE book = ?"
            }

            // 如果有輸入書名，就傳入參數；否則傳入 null
            val args = if (edBook.text.isEmpty()) null else arrayOf(edBook.text.toString())

            val c = dbrw.rawQuery(queryString, args)

            items.clear() // 清空舊資料
            showToast("共有${c.count}筆資料")

            c.moveToFirst() // 移動到第一筆
            // 使用 while 迴圈遍歷 Cursor
            for (i in 0 until c.count) {
                // 讀取欄位資料 (0: book, 1: price)
                items.add("書名:${c.getString(0)}\t\t\t\t價格:${c.getInt(1)}")
                c.moveToNext()
            }

            adapter.notifyDataSetChanged() // 更新 ListView
            c.close() // 務必關閉 Cursor
        }
    }

    private fun showToast(text: String) {
        Toast.makeText(this, text, Toast.LENGTH_LONG).show()
    }

    private fun cleanEditText() {
        edBook.setText("")
        edPrice.setText("")
    }
}

//防止 SQL Injection：原本的 Update、Delete 與 Query 使用字串串接 ('${edBook.text}') 是危險的，改用 ? 佔位符搭配 arrayOf() 傳入參數 。



//優化 View 查找：將 findViewById 移至 onCreate 初始化，避免每次點擊按鈕都重新尋找元件，提升效能。

//Cursor 處理：使用標準的 while (c.moveToNext()) 取代 for 迴圈，程式碼更簡潔。