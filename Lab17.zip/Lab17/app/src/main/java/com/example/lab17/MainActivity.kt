package com.example.lab17

import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.gson.Gson
import okhttp3.*
import java.io.IOException

class MainActivity : AppCompatActivity() {
    private lateinit var btnQuery: Button

    // 1. 優化：將 OkHttpClient 提升為類別屬性，避免每次請求都重新建立，節省資源
    private val client = OkHttpClient()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        btnQuery = findViewById(R.id.btnQuery)

        btnQuery.setOnClickListener {
            btnQuery.isEnabled = false
            setRequest()
        }
    }

    private fun setRequest() {
        val url = "https://api.italkutalk.com/api/air"

        // 建立 Request
        val req = Request.Builder().url(url).build()

        // 2. 優化：使用已建立好的 client 實例
        client.newCall(req).enqueue(object : Callback {
            override fun onResponse(call: Call, response: Response) {
                // 3. 優化：增加 isSuccessful 判斷，確保 HTTP 狀態碼為 200 OK
                if (!response.isSuccessful) {
                    handleFailure("伺服器錯誤: ${response.code}")
                    return
                }

                // 4. 優化：使用 safe call (?) 與 let 處理可能為 null 的 body
                response.body?.string()?.let { json ->
                    try {
                        val myObject = Gson().fromJson(json, MyObject::class.java)
                        // 切換回主執行緒顯示結果
                        runOnUiThread {
                            showDialog(myObject)
                        }
                    } catch (e: Exception) {
                        handleFailure("JSON 解析失敗: ${e.message}")
                    }
                } ?: handleFailure("回傳資料為空")
            }

            override fun onFailure(call: Call, e: IOException) {
                handleFailure("查詢失敗: $e")
            }
        })
    }

    // 5. 優化：將錯誤處理統一提取為一個方法，減少重複程式碼
    private fun handleFailure(message: String) {
        runOnUiThread {
            if (!isFinishing) { // 確保 Activity 還在執行中
                btnQuery.isEnabled = true
                Toast.makeText(this@MainActivity, message, Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun showDialog(myObject: MyObject) {
        // 6. 優化：使用 Kotlin 的 map 函式取代 forEach + add，語法更簡潔
        val items = myObject.result.records.map { data ->
            "地區：${data.SiteName}, 狀態：${data.Status}"
        }.toTypedArray()

        if (!isFinishing) {
            btnQuery.isEnabled = true
            AlertDialog.Builder(this@MainActivity)
                .setTitle("臺北市空氣品質")
                .setItems(items, null)
                .show()
        }
    }
}
/*
OkHttpClient 重用 (Reusability) ：

修改前：每次點擊按鈕都 OkHttpClient()，這會導致每次都建立新的連線池 (Connection Pool) 和執行緒池，浪費記憶體與網路資源。

修改後：宣告為 private val client = OkHttpClient()，整個 Activity 生命週期共用一個實例。

安全性檢查 (Safety)：

HTTP 狀態碼：原本只檢查 onResponse，但伺服器回傳 404 或 500 也會進入 onResponse。優化後增加了 if (!response.isSuccessful) 檢查。

Activity 狀態：在 runOnUiThread 中增加了 !isFinishing 檢查，防止 Activity 已經關閉但網路回傳導致的崩潰 (Crash)。

Kotlin 語法慣例 (Idiomatic Kotlin)：

集合處理：原本使用 mutableListOf 加上 forEach 迴圈來組裝字串。優化後使用標準的 .map { ... } 函式，直接將資料轉換為所需的格式，程式碼更漂亮且易讀。

Scope Functions：使用 .let 來處理 response.body?.string()，避免多層的 null 檢查。

錯誤處理統一：

將 onFailure 和解析錯誤的 UI 更新邏輯提取到 handleFailure 方法中，避免重複寫 runOnUiThread 和 Toast。*/